//
// Author : Samuel T. C. Santos
// Graph Data
// 

var treeData = (function(){

	var suites = [];

	function init(){
		suites.push({
		   name : 'TestSuiteA',
		   testcase : {
		     name: 'testA',
		     classcode : {
		       name : 'ClassA',
		       method : {
		         name : 'methodA',
		         lines : [1,2,11,15,17,19]
		       }
		     }
		   }
		});

		suites.push({
		   name : 'TestSuiteA',
		   testcase : {
		     name: 'testB',
		     classcode : {
		       name : 'ClassB',
		       method : {
		         name : 'methodB',
		         lines : [5,8,3,4,6,9]
		       }
		     }
		   }
		});
		suites.push({
		   name : 'TestSuiteB',
		   testcase : {
		     name: 'testC',
		     classcode : {
		       name : 'ClassC',
		       method : {
		         name : 'methodC',
		         lines : [50,80,30,40,60,90]
		       }
		     }
		   }
		});
		suites.push({
		   name : 'TestSuiteB',
		   testcase : {
		     name: 'testD',
		     classcode : {
		       name : 'ClassD',
		       method : {
		         name : 'methodD',
		         lines : [35,38,33,34,36,39]
		       }
		     }
		   }
		});
		suites.push({
		   name : 'TestSuiteC',
		   testcase : {
		     name: 'testE',
		     classcode : {
		       name : 'ClassE',
		       method : {
		         name : 'methodE',
		         lines : [150,155,154]
		       }
		     }
		   }
		});
		suites.push({
		   name : 'TestSuiteC',
		   testcase : {
		     name: 'testF',
		     classcode : {
		       name : 'ClassF',
		       method : {
		         name : 'methodF',
		         lines : [305,308,303,304,306,309,311]
		       }
		     }
		   }
		});
			
	}

	return {
		getData : function (){
			return suites;
		},
		load : function (){
			init();
		}
	};
})();
