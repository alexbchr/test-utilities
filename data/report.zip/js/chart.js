//
// Author: Samuel T. C. Santos
// Creating APFD chart
//
// Module Chart
// @see { http://samueltcsantos.github.io/priorj }

var APFDChart = (function (){

    var chart = {
        type : 'area'
    };

    var title = {
        text : 'APFD graph for prioritized test suite'
    };

    var credits = {
        enabled: false
    };

    var yAxis = {
        title: {
         text: 'Percentage of Faults Detected'
        }
    }

    var xAxis = {
        title: {
         text: 'Percentage of Test Suite Executed'
        }
    }

    var series = [];
    
    function Chart(chart, title, credits, series, xAxis, yAxis){
        this.chart = chart;
        this.title = title;
        this.credits = credits;
        this.series = series;
        this.yAxis = yAxis;
        this.xAxis = xAxis;
    }

    function getInstance(){
        var instance = new Chart(chart, title, credits, series, xAxis, yAxis);
        return instance;
    }

    return {
        setSeries : function (allseries){
            series = allseries;
        },
        getChart : function (){
            return getInstance();
        } 
    };
})();

