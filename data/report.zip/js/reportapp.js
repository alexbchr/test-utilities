
$(function(){
	var coverage = getCoverageReportData();
	var coverageGlobal = getCoverageGlobalData();
	fillTable();

	function fillTable(){
		$('#myTable').append('<thead>');
		var header = '<tr>';
		header += cellHeader('Test Suites (' + coverageGlobal.suites +')');
		header += cellHeader('Test Cases (' + coverageGlobal.testcases + ')');
		header += cellHeader('Classes (' + coverageGlobal.classes + ')');
		header += cellHeader('Methods (' + coverageGlobal.methods + ')');
		header += cellHeader('Statements (' + coverageGlobal.statements+')');
		header += '</tr>';
		$('#myTable').append(header);

		$('#myTable').append('</thead>');
		$('#myTable').append('<tbody>');
		
		for (var i=0; i < coverage.length; i++){
			var row = '<tr class="success" id="'+coverage[i].testcase+'">';
			row+= cellBody(coverage[i].testsuite);
			row+= cellBody(coverage[i].testcase);
			
			var value = coverage[i].classes;
			var total = coverageGlobal.classes;
			var percent = percentage(value,total);
			row+= cellBody(value + ' (' + percent +'%)');
			
			value = coverage[i].methods;
			total = coverageGlobal.methods;
			percent = percentage(value, total);
			row+= cellBody(value + ' (' + percent +'%)');
			
			value = coverage[i].statements;
			total = coverageGlobal.statements;
			percent = percentage(value, total);
			row+= cellBody(value + ' (' + percent +'%)');
			row += '</tr>';
			$('#myTable').append(row);
		}
		$('#myTable').append('</tbody>');

		highLightOnRows();
	}
	
	function getTestName(signature){
	   splited = signature.split('.');
	   var size = splited.length;
	   return splited[size-1];
	}
	
	function highLightOnRows(){
		var failures =  getFailures();
		failures.forEach(function (f){
			var id = getTestName(f); 
			$("#"+id).removeClass('success');
			$("#"+id).addClass('danger');
		});
	}

	function cellHeader(title){
		return '<th>' +title +'</th>';
	}

	function cellBody(content){
		return '<td>' +content +'</td>';
	}

	function percentage(value, total){
		var percent = value * 100 / total;
		return percent.toFixed(2);
	}

	function getSuiteSize(){
		return coverage.length;
	}

});

